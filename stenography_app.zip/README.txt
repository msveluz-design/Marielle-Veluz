Stenography Alphabet Interactive Web App
-------------------------------------
Files:
- index.html : single-file web app (includes CSS and JS inline)

How to use:
1. Unzip stenography_app.zip
2. Open index.html in a browser (Chrome, Edge, Firefox)
3. Click any symbol to see the mapped alphabet letter.
4. Use the search box to filter symbols or letters.
5. Press a letter key on your keyboard (when the page is focused) to quickly select a symbol mapped to that letter.

Notes:
- The "symbols" in this example are illustrative placeholders (e.g., "ST", "K", etc.). If you have actual stenography glyphs, replace the mapping array in the <script> section of index.html.
- This file is deliberately single-file to make it easy to hand in for class.
